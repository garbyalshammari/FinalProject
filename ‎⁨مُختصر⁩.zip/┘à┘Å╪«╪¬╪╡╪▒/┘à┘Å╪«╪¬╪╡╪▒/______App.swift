//
//  ______App.swift
//  مُختصر
//
//  Created by MacBook AIr on 28/03/2022.
//

import SwiftUI

@main
struct ______App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
